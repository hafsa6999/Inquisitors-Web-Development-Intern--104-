import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Code2,
  Compass,
  FileSearch,
  Gauge,
  Globe,
  Layers,
  LayoutTemplate,
  LineChart,
  Mail,
  MapPin,
  Menu,
  MessageSquare,
  Palette,
  Phone,
  PenTool,
  Rocket,
  Search,
  ShieldCheck,
  ShoppingBag,
  Smartphone,
  Sparkles,
  Star,
  TestTube2,
  Wrench,
  X,
  Github,
  Twitter,
  Linkedin,
  Instagram,
  ArrowUp,
  Play,
  Zap,
  Users,
  Award,
  Clock,
} from "lucide-react";
import heroImg from "@/assets/hero-mockup.jpg";
import aboutTeam from "@/assets/about-team.jpg";
import projSaas from "@/assets/project-saas.jpg";
import projCorporate from "@/assets/project-corporate.jpg";
import projEcom from "@/assets/project-ecom.jpg";
import projHealth from "@/assets/project-health.jpg";
import projRestaurant from "@/assets/project-restaurant.jpg";
import projRealestate from "@/assets/project-realestate.jpg";
import projStartup from "@/assets/project-startup.jpg";
import projEducation from "@/assets/project-education.jpg";
import avatar1 from "@/assets/avatar-1.jpg";
import avatar2 from "@/assets/avatar-2.jpg";
import avatar3 from "@/assets/avatar-3.jpg";
import blog1 from "@/assets/blog-1.jpg";
import blog2 from "@/assets/blog-2.jpg";
import blog3 from "@/assets/blog-3.jpg";

export const Route = createFileRoute("/")({
  component: AgencyLanding,
});

const NAV = [
  { label: "Home", href: "#home" },
  { label: "Services", href: "#services" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "About", href: "#about" },
  { label: "Process", href: "#process" },
  { label: "Pricing", href: "#pricing" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "FAQ", href: "#faq" },
  { label: "Contact", href: "#contact" },
];

function AgencyLanding() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 12);
      setShowTop(window.scrollY > 600);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div id="home" className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Nav scrolled={scrolled} menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <main>
        <Hero />
        <TrustBar />
        <Services />
        <Portfolio />
        <About />
        <Process />
        <WhyChooseUs />
        <Pricing />
        <Testimonials />
        <Faq />
        <Blog />
        <Contact />
      </main>
      <Footer />
      <BackToTop show={showTop} />
    </div>
  );
}

/* ---------------- Nav ---------------- */
function Nav({
  scrolled,
  menuOpen,
  setMenuOpen,
}: {
  scrolled: boolean;
  menuOpen: boolean;
  setMenuOpen: (v: boolean) => void;
}) {
  return (
    <header
      className={[
        "fixed top-0 inset-x-0 z-50 transition-all duration-300",
        scrolled ? "py-2" : "py-4",
      ].join(" ")}
    >
      <div className="mx-auto max-w-7xl px-4">
        <div
          className={[
            "flex items-center justify-between rounded-2xl px-4 sm:px-5 py-3 transition-all",
            scrolled ? "glass shadow-soft" : "bg-transparent",
          ].join(" ")}
        >
          <a href="#home" className="flex items-center gap-2 shrink-0">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-brand shadow-glow">
              <Sparkles className="h-4 w-4 text-white" />
            </span>
            <span className="font-extrabold text-lg tracking-tight text-ink">
              Lumen<span className="text-primary">.</span>
            </span>
          </a>

          <nav className="hidden lg:flex items-center gap-1">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-sm font-medium text-muted-foreground hover:text-foreground px-3 py-2 rounded-lg hover:bg-secondary transition-colors"
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="hidden lg:block">
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-brand px-4 py-2.5 text-sm font-semibold text-white shadow-glow hover:opacity-95 transition"
            >
              Book a Free Consultation
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>

          <button
            aria-label="Toggle menu"
            className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-lg hover:bg-secondary"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {menuOpen && (
          <div className="lg:hidden mt-2 glass rounded-2xl shadow-soft p-3 animate-in fade-in slide-in-from-top-2">
            <div className="grid gap-1">
              {NAV.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setMenuOpen(false)}
                  className="px-3 py-2.5 rounded-lg text-sm font-medium text-foreground hover:bg-secondary"
                >
                  {item.label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setMenuOpen(false)}
                className="mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-brand px-4 py-3 text-sm font-semibold text-white"
              >
                Book a Free Consultation
                <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

/* ---------------- Hero ---------------- */
function Hero() {
  return (
    <section className="relative pt-32 sm:pt-40 pb-20 bg-gradient-hero">
      <div className="mx-auto max-w-7xl px-4">
        <div className="grid lg:grid-cols-[1.1fr_1fr] gap-12 lg:gap-16 items-center">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs font-medium text-ink shadow-soft">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Now booking Q3 projects
            </div>
            <h1 className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-black leading-[1.05] text-ink">
              We build websites that help{" "}
              <span className="text-gradient-brand">businesses grow.</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl leading-relaxed">
              We design and develop modern, responsive, SEO-friendly websites that convert
              visitors into customers. From custom websites to WordPress solutions, we help
              businesses establish a powerful online presence.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a
                href="#contact"
                className="inline-flex items-center gap-2 rounded-xl bg-gradient-brand px-5 py-3 text-sm font-semibold text-white shadow-glow hover:opacity-95 transition"
              >
                Start Your Project
                <ArrowRight className="h-4 w-4" />
              </a>
              <a
                href="#portfolio"
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-white px-5 py-3 text-sm font-semibold text-ink hover:bg-secondary transition"
              >
                <Play className="h-4 w-4" />
                View Our Work
              </a>
            </div>

            <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl">
              <Stat value={300} suffix="+" label="Projects Delivered" />
              <Stat value={200} suffix="+" label="Happy Clients" />
              <Stat value={98} suffix="%" label="Client Satisfaction" />
              <Stat value={5} suffix="+" label="Years Experience" />
            </div>
          </div>

          <HeroMockup />
        </div>
      </div>
    </section>
  );
}

function Stat({ value, suffix, label }: { value: number; suffix?: string; label: string }) {
  const [n, setN] = useState(0);
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          const start = performance.now();
          const dur = 1200;
          const tick = (t: number) => {
            const p = Math.min(1, (t - start) / dur);
            setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
            if (p < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
          io.disconnect();
        }
      },
      { threshold: 0.4 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [value]);
  return (
    <div ref={ref}>
      <div className="text-3xl font-extrabold text-ink tabular-nums">
        {n}
        {suffix}
      </div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
    </div>
  );
}

function HeroMockup() {
  return (
    <div className="relative">
      <div className="relative aspect-[5/4] w-full">
        {/* Floating shapes */}
        <div className="absolute -top-6 -left-4 h-24 w-24 rounded-3xl bg-gradient-brand opacity-70 blur-2xl" />
        <div className="absolute -bottom-6 -right-4 h-32 w-32 rounded-full bg-accent/50 blur-3xl" />

        {/* Hero mockup image */}
        <div className="absolute inset-0 rounded-3xl overflow-hidden border border-border shadow-glow animate-float-slow bg-white">
          <img
            src={heroImg}
            alt="Modern website mockup designed by Lumen Studio"
            width={1280}
            height={1024}
            className="h-full w-full object-cover"
          />
        </div>

        {/* Floating UI card 1 */}
        <div className="absolute -left-4 sm:-left-10 bottom-10 glass rounded-2xl shadow-soft p-3 flex items-center gap-3 animate-float">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-brand">
            <Gauge className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Performance</div>
            <div className="text-sm font-bold text-ink">100 / 100</div>
          </div>
        </div>

        {/* Floating UI card 2 */}
        <div className="absolute -right-3 sm:-right-6 top-8 glass rounded-2xl shadow-soft p-3 flex items-center gap-3 animate-float-slow">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-ink">
            <Star className="h-5 w-5 text-accent" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground">Client rating</div>
            <div className="text-sm font-bold text-ink">4.9 / 5.0</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Trust Bar ---------------- */
function TrustBar() {
  const logos = ["Northwind", "Acme Co", "Globex", "Initech", "Umbrella", "Hooli", "Stark"];
  return (
    <section className="py-10 border-y border-border bg-secondary/40">
      <div className="mx-auto max-w-7xl px-4">
        <p className="text-center text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Trusted by ambitious teams worldwide
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-x-10 gap-y-4 opacity-70">
          {logos.map((l) => (
            <span key={l} className="text-lg font-bold tracking-tight text-ink/70">
              {l}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Services ---------------- */
const SERVICES = [
  { icon: LayoutTemplate, title: "Custom Website Design", desc: "Unique, brand-driven designs crafted to convert." },
  { icon: Code2, title: "Frontend Development", desc: "Pixel-perfect React & Next.js interfaces." },
  { icon: Layers, title: "Full Stack Development", desc: "End-to-end web apps with robust backends." },
  { icon: Globe, title: "WordPress Development", desc: "Custom themes, plugins, and headless setups." },
  { icon: ShoppingBag, title: "E-commerce Development", desc: "Shopify, WooCommerce & custom storefronts." },
  { icon: Rocket, title: "Landing Pages", desc: "High-converting pages for campaigns & launches." },
  { icon: PenTool, title: "UI/UX Design", desc: "Research-led, delightful product experiences." },
  { icon: Sparkles, title: "Website Redesign", desc: "Modernize your site without losing SEO equity." },
  { icon: Search, title: "SEO Optimization", desc: "Technical, on-page & content SEO that ranks." },
  { icon: Wrench, title: "Website Maintenance", desc: "Updates, backups & 24/7 monitoring." },
  { icon: Zap, title: "Performance Optimization", desc: "Blazing Core Web Vitals across every device." },
  { icon: Palette, title: "Branding & Logo Design", desc: "Identity systems that scale with your brand." },
];

function Services() {
  return (
    <Section id="services" eyebrow="What we do" title="Services built to help you grow" desc="From strategy to launch and beyond — a full-service digital partner.">
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {SERVICES.map(({ icon: Icon, title, desc }) => (
          <div
            key={title}
            className="group relative rounded-2xl border border-border bg-card p-6 shadow-soft hover:-translate-y-1 hover:shadow-glow transition-all"
          >
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-brand shadow-glow">
              <Icon className="h-6 w-6 text-white" />
            </div>
            <h3 className="mt-5 text-lg font-bold text-ink">{title}</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{desc}</p>
            <a
              href="#contact"
              className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all"
            >
              Learn more <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ---------------- Portfolio ---------------- */
const CATEGORIES = ["All", "Corporate", "Startup", "E-commerce", "Healthcare", "Restaurant", "Real Estate", "SaaS", "Education"];

const PROJECTS = [
  { name: "Vertex Analytics", industry: "SaaS", cat: "SaaS", tech: ["Next.js", "TypeScript", "Postgres"], img: projSaas },
  { name: "Harbor Bank", industry: "Corporate", cat: "Corporate", tech: ["React", "Node", "Sanity"], img: projCorporate },
  { name: "Bloom Market", industry: "E-commerce", cat: "E-commerce", tech: ["Shopify", "Hydrogen"], img: projEcom },
  { name: "Northwell Care", industry: "Healthcare", cat: "Healthcare", tech: ["Next.js", "Contentful"], img: projHealth },
  { name: "Ember Kitchen", industry: "Restaurant", cat: "Restaurant", tech: ["WordPress", "WooCommerce"], img: projRestaurant },
  { name: "Ridgeline Homes", industry: "Real Estate", cat: "Real Estate", tech: ["Next.js", "Mapbox"], img: projRealestate },
  { name: "LaunchPad", industry: "Startup", cat: "Startup", tech: ["React", "Framer"], img: projStartup },
  { name: "Scholar OS", industry: "Education", cat: "Education", tech: ["Next.js", "Supabase"], img: projEducation },
];

function Portfolio() {
  const [active, setActive] = useState("All");
  const filtered = active === "All" ? PROJECTS : PROJECTS.filter((p) => p.cat === active);
  return (
    <Section id="portfolio" eyebrow="Selected work" title="Projects we're proud of" desc="A glimpse of the brands we've helped bring to life on the web.">
      <div className="flex flex-wrap gap-2 justify-center mb-10">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setActive(c)}
            className={[
              "px-4 py-2 rounded-full text-sm font-medium border transition-all",
              active === c
                ? "bg-ink text-white border-ink"
                : "bg-white text-muted-foreground border-border hover:border-ink/40 hover:text-ink",
            ].join(" ")}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((p) => (
          <article
            key={p.name}
            className="group rounded-2xl overflow-hidden border border-border bg-card shadow-soft hover:shadow-glow transition-all"
          >
            <div className="relative aspect-[4/3] overflow-hidden bg-secondary">
              <img
                src={p.img}
                alt={`${p.name} — ${p.industry} website`}
                loading="lazy"
                width={1200}
                height={900}
                className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="font-bold text-ink truncate">{p.name}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">{p.industry}</p>
                </div>
                <a
                  href="#"
                  aria-label="Live preview"
                  className="shrink-0 grid h-9 w-9 place-items-center rounded-lg bg-secondary hover:bg-ink hover:text-white transition"
                >
                  <ArrowUpRight className="h-4 w-4" />
                </a>
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {p.tech.map((t) => (
                  <span key={t} className="text-xs px-2 py-1 rounded-md bg-secondary text-muted-foreground">
                    {t}
                  </span>
                ))}
              </div>
              <div className="mt-4 flex gap-2">
                <a href="#" className="flex-1 text-center text-xs font-semibold rounded-lg border border-border py-2 hover:bg-secondary">
                  Live Preview
                </a>
                <a href="#" className="flex-1 text-center text-xs font-semibold rounded-lg bg-ink text-white py-2 hover:opacity-90">
                  Case Study
                </a>
              </div>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}

/* ---------------- About ---------------- */
function About() {
  const values = [
    { icon: Compass, title: "Mission", desc: "Craft websites that turn attention into growth for ambitious brands." },
    { icon: Sparkles, title: "Vision", desc: "Become the studio teams trust when the web work has to be exceptional." },
    { icon: ShieldCheck, title: "Values", desc: "Craft, honesty, curiosity, and a relentless bias for shipping." },
  ];
  return (
    <Section id="about" eyebrow="About us" title="A small studio with a big obsession for the web">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div className="relative">
          <div className="absolute -inset-4 rounded-3xl bg-gradient-brand opacity-20 blur-2xl" />
          <img
            src={aboutTeam}
            alt="Lumen Studio team collaborating"
            loading="lazy"
            width={1200}
            height={1000}
            className="relative rounded-3xl border border-border shadow-glow w-full h-auto object-cover"
          />
        </div>
        <div>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Lumen Studio is a team of designers, developers, and strategists building websites and
            digital products for founders and marketing leaders. We combine strategy, design, and
            engineering under one roof — so your brand ships faster and performs better.
          </p>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Since 2020, we've partnered with 200+ companies across SaaS, e-commerce, healthcare, and
            real estate. Every project is led by a senior team member — no juniors handed the keys.
          </p>
          <div className="mt-8 grid grid-cols-2 gap-4">
            <MiniStat icon={Users} value="200+" label="Clients" />
            <MiniStat icon={Award} value="15" label="Industry Awards" />
            <MiniStat icon={Rocket} value="300+" label="Sites Launched" />
            <MiniStat icon={Clock} value="5+ yrs" label="In Business" />
          </div>
          <div className="mt-8 grid sm:grid-cols-3 gap-3">
            {values.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="rounded-2xl border border-border bg-card p-5 shadow-soft">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-brand shadow-glow">
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <h3 className="mt-3 font-bold text-ink">{title}</h3>
                <p className="mt-1 text-xs text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  );
}

function MiniStat({ icon: Icon, value, label }: { icon: any; value: string; label: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 flex items-center gap-3">
      <div className="grid h-10 w-10 place-items-center rounded-lg bg-secondary text-primary">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <div className="font-extrabold text-ink">{value}</div>
        <div className="text-xs text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}

/* ---------------- Process ---------------- */
const PROCESS = [
  { icon: Phone, title: "Discovery Call", desc: "We learn about your goals, users, and constraints." },
  { icon: FileSearch, title: "Research", desc: "Competitor scan, user insights, technical audit." },
  { icon: LineChart, title: "Strategy", desc: "Positioning, IA, roadmap and success metrics." },
  { icon: LayoutTemplate, title: "Wireframing", desc: "Low-fi flows to validate structure early." },
  { icon: PenTool, title: "UI/UX Design", desc: "High-fidelity design in your brand system." },
  { icon: Code2, title: "Development", desc: "Clean, accessible, scalable engineering." },
  { icon: TestTube2, title: "Testing", desc: "QA across browsers, devices, and accessibility." },
  { icon: Rocket, title: "Launch", desc: "Smooth deployment with zero-downtime cutover." },
  { icon: Wrench, title: "Ongoing Support", desc: "Care plans to keep your site fast & secure." },
];

function Process() {
  return (
    <Section id="process" eyebrow="How we work" title="A proven process, from idea to launch">
      <div className="relative grid md:grid-cols-2 lg:grid-cols-3 gap-5">
        {PROCESS.map((s, i) => (
          <div
            key={s.title}
            className="relative rounded-2xl border border-border bg-card p-6 shadow-soft hover:shadow-glow hover:-translate-y-1 transition-all"
          >
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-ink text-white text-sm font-bold">
                {String(i + 1).padStart(2, "0")}
              </span>
              <s.icon className="h-5 w-5 text-primary" />
            </div>
            <h3 className="mt-4 font-bold text-ink">{s.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ---------------- Why choose us ---------------- */
const WHY = [
  { icon: Smartphone, t: "Mobile-First Design" },
  { icon: Search, t: "SEO Optimized" },
  { icon: Zap, t: "Lightning Fast Performance" },
  { icon: ShieldCheck, t: "Secure Development" },
  { icon: Code2, t: "Clean Code" },
  { icon: Layers, t: "Scalable Architecture" },
  { icon: MessageSquare, t: "Transparent Communication" },
  { icon: Users, t: "Dedicated Support" },
  { icon: Clock, t: "On-Time Delivery" },
];

function WhyChooseUs() {
  return (
    <section className="py-24 bg-ink text-white relative overflow-hidden">
      <div className="absolute -top-40 -right-40 h-96 w-96 rounded-full bg-primary/30 blur-3xl" />
      <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-accent/20 blur-3xl" />
      <div className="mx-auto max-w-7xl px-4 relative">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold uppercase tracking-widest text-accent">Why choose us</p>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-black leading-tight">
            The details that make websites work.
          </h2>
          <p className="mt-4 text-white/70 text-lg">
            We sweat the fundamentals so your site earns trust, ranks well, and converts.
          </p>
        </div>
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {WHY.map(({ icon: Icon, t }) => (
            <div
              key={t}
              className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur p-5 flex items-center gap-4 hover:bg-white/10 transition"
            >
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-brand shadow-glow">
                <Icon className="h-5 w-5 text-white" />
              </div>
              <div className="font-semibold">{t}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- Pricing ---------------- */
const PLANS = [
  {
    name: "Starter",
    price: "$1,499",
    tagline: "For small businesses getting online.",
    features: ["Small business website", "Responsive design", "Contact form", "Basic SEO"],
    highlight: false,
  },
  {
    name: "Professional",
    price: "$3,999",
    tagline: "For growing brands that need more.",
    features: ["Business website", "CMS integration", "Blog", "SEO", "Speed optimization"],
    highlight: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    tagline: "For teams with complex needs.",
    features: ["Custom web application", "API integration", "Unlimited pages", "Advanced features", "Priority support"],
    highlight: false,
  },
];

function Pricing() {
  return (
    <Section id="pricing" eyebrow="Pricing" title="Simple, transparent pricing" desc="Fixed-scope engagements. No surprise invoices.">
      <div className="grid md:grid-cols-3 gap-6">
        {PLANS.map((p) => (
          <div
            key={p.name}
            className={[
              "relative rounded-3xl p-8 border transition-all",
              p.highlight
                ? "bg-ink text-white border-ink shadow-glow lg:-translate-y-2"
                : "bg-card text-ink border-border shadow-soft hover:-translate-y-1",
            ].join(" ")}
          >
            {p.highlight && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-brand px-3 py-1 text-xs font-bold text-white shadow-glow">
                Most popular
              </span>
            )}
            <h3 className="text-lg font-bold">{p.name}</h3>
            <p className={p.highlight ? "text-white/70 text-sm mt-1" : "text-muted-foreground text-sm mt-1"}>
              {p.tagline}
            </p>
            <div className="mt-6 flex items-baseline gap-1">
              <span className="text-4xl font-black tracking-tight">{p.price}</span>
              {p.price !== "Custom" && (
                <span className={p.highlight ? "text-white/60 text-sm" : "text-muted-foreground text-sm"}>
                  / project
                </span>
              )}
            </div>
            <ul className="mt-6 space-y-3">
              {p.features.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm">
                  <Check className={p.highlight ? "h-5 w-5 shrink-0 text-accent" : "h-5 w-5 shrink-0 text-primary"} />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            <a
              href="#contact"
              className={[
                "mt-8 inline-flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition",
                p.highlight
                  ? "bg-gradient-brand text-white shadow-glow hover:opacity-95"
                  : "bg-ink text-white hover:opacity-90",
              ].join(" ")}
            >
              Get started <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ---------------- Testimonials ---------------- */
const TESTIMONIALS = [
  {
    quote:
      "Lumen rebuilt our marketing site in six weeks. Conversions jumped 42% in the first month. The team is a genuine pleasure to work with.",
    name: "Amelia Chen",
    role: "Head of Growth",
    company: "Vertex Analytics",
    avatar: avatar1,
  },
  {
    quote:
      "Best web partner we've hired. Sharp design, clean code, and communication that actually respects our time. Already planning phase two.",
    name: "Marcus Reyes",
    role: "Founder & CEO",
    company: "LaunchPad",
    avatar: avatar2,
  },
  {
    quote:
      "They translated our brand into a site that finally feels like us — and it loads in under a second. Cannot recommend them enough.",
    name: "Priya Patel",
    role: "Marketing Director",
    company: "Bloom Market",
    avatar: avatar3,
  },
];

function Testimonials() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setI((v) => (v + 1) % TESTIMONIALS.length), 6000);
    return () => clearInterval(id);
  }, []);
  const t = TESTIMONIALS[i];
  return (
    <Section id="testimonials" eyebrow="Testimonials" title="What our clients say">
      <div className="relative max-w-3xl mx-auto rounded-3xl border border-border bg-card shadow-soft p-8 sm:p-12">
        <div className="flex gap-1 text-amber-400">
          {Array.from({ length: 5 }).map((_, k) => (
            <Star key={k} className="h-5 w-5 fill-current" />
          ))}
        </div>
        <blockquote className="mt-6 text-xl sm:text-2xl font-medium leading-relaxed text-ink">
          "{t.quote}"
        </blockquote>
        <div className="mt-8 flex items-center gap-4">
          <img
            src={t.avatar}
            alt={t.name}
            loading="lazy"
            width={64}
            height={64}
            className="h-14 w-14 rounded-full object-cover border-2 border-white shadow-soft"
          />
          <div>
            <div className="font-bold text-ink">{t.name}</div>
            <div className="text-sm text-muted-foreground">
              {t.role} · {t.company}
            </div>
          </div>
        </div>
        <div className="mt-8 flex items-center gap-2">
          {TESTIMONIALS.map((_, k) => (
            <button
              key={k}
              onClick={() => setI(k)}
              aria-label={`Testimonial ${k + 1}`}
              className={[
                "h-2 rounded-full transition-all",
                k === i ? "w-8 bg-ink" : "w-2 bg-border hover:bg-muted-foreground/60",
              ].join(" ")}
            />
          ))}
        </div>
      </div>
    </Section>
  );
}

/* ---------------- FAQ ---------------- */
const FAQS = [
  { q: "How long does a website take?", a: "Most marketing sites take 4–8 weeks. Complex web apps run 10–16+ weeks. We share a tight timeline after our discovery call." },
  { q: "Do you redesign existing websites?", a: "Yes — redesigns are one of our specialties. We preserve SEO equity while modernizing design, performance, and conversion." },
  { q: "What technologies do you use?", a: "Primarily React, Next.js, TypeScript, Tailwind CSS, and headless CMS platforms. For WordPress we build custom themes and headless setups." },
  { q: "Do you provide SEO?", a: "Every site ships SEO-ready: semantic HTML, sitemap, structured data, and Core Web Vitals tuning. We also offer ongoing SEO retainers." },
  { q: "Do you provide ongoing maintenance?", a: "Yes. Our care plans cover updates, backups, uptime monitoring, and monthly performance & security reports." },
];

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section id="faq" eyebrow="FAQ" title="Frequently asked questions">
      <div className="max-w-3xl mx-auto space-y-3">
        {FAQS.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={f.q} className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left"
                aria-expanded={isOpen}
              >
                <span className="font-semibold text-ink">{f.q}</span>
                <ChevronDown
                  className={[
                    "h-5 w-5 shrink-0 text-muted-foreground transition-transform",
                    isOpen ? "rotate-180" : "",
                  ].join(" ")}
                />
              </button>
              <div
                className={[
                  "grid transition-all duration-300 ease-out px-6",
                  isOpen ? "grid-rows-[1fr] opacity-100 pb-5" : "grid-rows-[0fr] opacity-0",
                ].join(" ")}
              >
                <div className="overflow-hidden text-sm text-muted-foreground leading-relaxed">
                  {f.a}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Section>
  );
}

/* ---------------- Blog ---------------- */
const POSTS = [
  {
    title: "How we cut a client's LCP by 68% in one week",
    cat: "Performance",
    author: "Ada Wren",
    date: "Jul 12, 2026",
    img: blog1,
  },
  {
    title: "The design system playbook we use for every launch",
    cat: "Design",
    author: "Noah Park",
    date: "Jun 28, 2026",
    img: blog2,
  },
  {
    title: "Headless WordPress in 2026: is it worth it?",
    cat: "Engineering",
    author: "Lena Ortiz",
    date: "Jun 09, 2026",
    img: blog3,
  },
];

function Blog() {
  return (
    <Section id="blog" eyebrow="Journal" title="Fresh writing from the studio">
      <div className="grid md:grid-cols-3 gap-6">
        {POSTS.map((p) => (
          <article
            key={p.title}
            className="group rounded-2xl overflow-hidden border border-border bg-card shadow-soft hover:shadow-glow hover:-translate-y-1 transition-all"
          >
            <div className="aspect-[16/10] relative overflow-hidden">
              <img
                src={p.img}
                alt={p.title}
                loading="lazy"
                width={1200}
                height={750}
                className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <span className="absolute top-4 left-4 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-ink shadow-soft">
                {p.cat}
              </span>
            </div>
            <div className="p-6">
              <h3 className="font-bold text-ink text-lg leading-snug group-hover:text-primary transition">
                {p.title}
              </h3>
              <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                <span>
                  {p.author} · {p.date}
                </span>
                <a href="#" className="inline-flex items-center gap-1 font-semibold text-primary">
                  Read more <ArrowUpRight className="h-3.5 w-3.5" />
                </a>
              </div>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}

/* ---------------- Contact ---------------- */
function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <Section id="contact" eyebrow="Contact" title="Let's build something great" desc="Tell us about your project — we'll reply within one business day.">
      <div className="grid lg:grid-cols-[1.1fr_1fr] gap-8">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSent(true);
          }}
          className="rounded-3xl border border-border bg-card p-6 sm:p-8 shadow-soft"
        >
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Name" name="name" required />
            <Field label="Email" name="email" type="email" required />
            <Field label="Phone" name="phone" type="tel" />
            <Field label="Company" name="company" />
          </div>
          <div className="mt-4">
            <label className="block text-sm font-medium text-ink mb-1.5">Budget</label>
            <select className="w-full rounded-xl border border-border bg-white px-4 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-ring transition">
              <option>Under $2,000</option>
              <option>$2,000 – $5,000</option>
              <option>$5,000 – $15,000</option>
              <option>$15,000 – $50,000</option>
              <option>$50,000+</option>
            </select>
          </div>
          <div className="mt-4">
            <label className="block text-sm font-medium text-ink mb-1.5">Project details</label>
            <textarea
              rows={5}
              className="w-full rounded-xl border border-border bg-white px-4 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-ring transition resize-none"
              placeholder="Tell us about your goals, timeline, and anything else that matters..."
            />
          </div>
          <button
            type="submit"
            className="mt-6 inline-flex items-center justify-center gap-2 w-full rounded-xl bg-gradient-brand px-5 py-3.5 text-sm font-semibold text-white shadow-glow hover:opacity-95 transition"
          >
            {sent ? "Thanks — we'll be in touch!" : "Send message"}
            <ArrowRight className="h-4 w-4" />
          </button>
        </form>

        <div className="space-y-4">
          <ContactItem icon={Mail} title="Email" value="hello@lumen.studio" />
          <ContactItem icon={Phone} title="Phone" value="+1 (415) 555-0117" />
          <ContactItem icon={MapPin} title="Office" value="221B Market St, Suite 400, San Francisco, CA" />
          <ContactItem icon={Clock} title="Business Hours" value="Mon – Fri · 9:00 AM – 6:00 PM PT" />

          <div className="rounded-3xl overflow-hidden border border-border shadow-soft h-64 relative bg-gradient-to-br from-primary/10 via-accent/10 to-primary/10">
            <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle_at_30%_30%,white,transparent_40%),radial-gradient(circle_at_70%_60%,white,transparent_35%)]" />
            <div className="absolute inset-0 grid place-items-center">
              <div className="glass rounded-2xl px-4 py-3 flex items-center gap-2 shadow-soft">
                <MapPin className="h-4 w-4 text-primary" />
                <span className="text-sm font-semibold text-ink">San Francisco, CA</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            {[Twitter, Linkedin, Instagram, Github].map((I, k) => (
              <a
                key={k}
                href="#"
                aria-label="social"
                className="grid h-10 w-10 place-items-center rounded-xl border border-border bg-white hover:bg-ink hover:text-white transition"
              >
                <I className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </Section>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="block text-sm font-medium text-ink mb-1.5">
        {label} {required && <span className="text-primary">*</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        className="w-full rounded-xl border border-border bg-white px-4 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-ring transition"
      />
    </div>
  );
}

function ContactItem({ icon: Icon, title, value }: { icon: any; title: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-soft flex items-start gap-4">
      <div className="shrink-0 grid h-11 w-11 place-items-center rounded-xl bg-gradient-brand shadow-glow">
        <Icon className="h-5 w-5 text-white" />
      </div>
      <div className="min-w-0">
        <div className="text-xs text-muted-foreground uppercase tracking-wide font-semibold">{title}</div>
        <div className="mt-0.5 font-semibold text-ink break-words">{value}</div>
      </div>
    </div>
  );
}

/* ---------------- Footer ---------------- */
function Footer() {
  return (
    <footer className="bg-ink text-white pt-16 pb-8 relative overflow-hidden">
      <div className="absolute -top-24 right-0 h-64 w-64 rounded-full bg-primary/20 blur-3xl" />
      <div className="mx-auto max-w-7xl px-4 relative">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <a href="#home" className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-brand shadow-glow">
                <Sparkles className="h-4 w-4 text-white" />
              </span>
              <span className="font-extrabold text-lg tracking-tight">Lumen.</span>
            </a>
            <p className="mt-4 text-sm text-white/60 max-w-xs leading-relaxed">
              A web design & development studio building fast, beautiful websites that grow
              ambitious brands.
            </p>
            <div className="mt-5 flex items-center gap-3">
              {[Twitter, Linkedin, Instagram, Github].map((I, k) => (
                <a
                  key={k}
                  href="#"
                  aria-label="social"
                  className="grid h-9 w-9 place-items-center rounded-lg border border-white/10 hover:bg-white/10 transition"
                >
                  <I className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <FooterCol
            title="Quick links"
            items={[
              ["Home", "#home"],
              ["About", "#about"],
              ["Portfolio", "#portfolio"],
              ["Process", "#process"],
              ["Contact", "#contact"],
            ]}
          />
          <FooterCol
            title="Services"
            items={[
              ["Custom Web Design", "#services"],
              ["Frontend Development", "#services"],
              ["WordPress", "#services"],
              ["E-commerce", "#services"],
              ["SEO Optimization", "#services"],
            ]}
          />

          <div>
            <h4 className="font-semibold">Newsletter</h4>
            <p className="mt-3 text-sm text-white/60">Occasional web craft, no spam.</p>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="mt-4 flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 p-1"
            >
              <input
                type="email"
                required
                placeholder="you@company.com"
                className="flex-1 bg-transparent px-3 py-2 text-sm outline-none placeholder:text-white/40"
              />
              <button className="rounded-lg bg-gradient-brand px-3 py-2 text-sm font-semibold text-white shadow-glow">
                Join
              </button>
            </form>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/50">
          <div>© {new Date().getFullYear()} Lumen Studio. All rights reserved.</div>
          <div className="flex items-center gap-5">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms & Conditions</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, items }: { title: string; items: [string, string][] }) {
  return (
    <div>
      <h4 className="font-semibold">{title}</h4>
      <ul className="mt-4 space-y-2.5">
        {items.map(([label, href]) => (
          <li key={label}>
            <a href={href} className="text-sm text-white/60 hover:text-white transition">
              {label}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ---------------- Reusable ---------------- */
function Section({
  id,
  eyebrow,
  title,
  desc,
  children,
}: {
  id: string;
  eyebrow: string;
  title: string;
  desc?: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="py-24 scroll-mt-24">
      <div className="mx-auto max-w-7xl px-4">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <p className="text-xs font-semibold uppercase tracking-widest text-primary">{eyebrow}</p>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-ink">
            {title}
          </h2>
          {desc && <p className="mt-4 text-lg text-muted-foreground leading-relaxed">{desc}</p>}
        </div>
        {children}
      </div>
    </section>
  );
}

function BackToTop({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      aria-label="Back to top"
      className="fixed bottom-6 right-6 z-40 grid h-12 w-12 place-items-center rounded-full bg-gradient-brand text-white shadow-glow hover:opacity-95 transition animate-in fade-in"
    >
      <ArrowUp className="h-5 w-5" />
    </button>
  );
}
